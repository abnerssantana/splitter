import os
import xml.etree.ElementTree as ET
from xml.dom import minidom

def merge_xml_files():
    # Diretório onde estão os arquivos XML separados
    input_dir = 'separados'
    
    # Criar elemento raiz para o arquivo combinado
    merged_root = ET.Element('nfseList')
    
    try:
        # Processar cada arquivo XML no diretório de entrada
        for filename in os.listdir(input_dir):
            if filename.endswith('.xml'):
                file_path = os.path.join(input_dir, filename)
                
                # Ler e parsear o arquivo XML
                tree = ET.parse(file_path)
                root = tree.getroot()
                
                # Adicionar o elemento CompNfse ao arquivo combinado
                merged_root.append(root)
        
        # Converter para string com formatação adequada
        xml_str = ET.tostring(merged_root, encoding='utf-8')
        pretty_xml = minidom.parseString(xml_str).toprettyxml(indent="  ")
        
        # Salvar o arquivo combinado
        output_file = 'notas_combinadas.xml'
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(pretty_xml)
            
        print(f"Arquivos XML combinados com sucesso. Arquivo salvo como: {output_file}")
        
    except Exception as e:
        print(f"Ocorreu um erro: {e}")

if __name__ == "__main__":
    merge_xml_files()